# Master Education — সহজে নতুন Page / Link যোগ করার নিয়ম

এই website এখন **central menu/footer system** ব্যবহার করে।

## 1. নতুন Page যোগ করতে

ধরুন আপনি `voice.html` নামে নতুন page বানালেন।

`site-data.js` খুলে `navigation`-এর মধ্যে এই line যোগ করুন:

```js
{ title: 'Voice', url: 'voice.html' },
```

Save → GitHub-এ upload/commit → website refresh।

নতুন page-এর link সব page-এর **top menu**-তে automatically আসবে এবং current page হলে active দেখাবে।

## 2. নতুন YouTube / External Link যোগ করতে

```js
{ title: 'YouTube Channel', url: 'https://www.youtube.com/@YourChannel', external: true },
```

`external: true` দিলে link নতুন tab-এ খুলবে।

## 3. Footer-এ link যোগ করতে

`site-data.js`-এর `footer` section-এ group-এর `links`-এর মধ্যে যোগ করুন:

```js
{ title: 'My New Page', url: 'my-new-page.html' }
```

## 4. নতুন page-এর জন্য কী করতে হবে?

1. নতুন HTML file তৈরি করুন, যেমন `grammar.html`
2. file-টি website-এর root folder-এ রাখুন
3. `site-data.js`-এ যোগ করুন:

```js
{ title: 'Grammar', url: 'grammar.html' }
```

4. GitHub-এ দুইটি file upload/commit করুন:
   - `grammar.html`
   - updated `site-data.js`

ব্যস। অন্য কোনো HTML page-এর menu edit করতে হবে না।

## 5. গুরুত্বপূর্ণ

`site-data.js` এবং `script.js` ফাইল delete/rename করবেন না।

নতুন page যদি root folder-এর বদলে কোনো folder-এর ভিতরে থাকে, URL হবে যেমন:

```js
{ title: 'New Lesson', url: 'lessons/new-lesson.html' }
```

## 6. সবচেয়ে সহজ workflow

**নতুন page:** HTML file → `site-data.js`-এ ১ line → GitHub update।

**নতুন external link:** শুধু `site-data.js`-এ ১ line।

**Menu/footer পরিবর্তন:** শুধু `site-data.js` edit করুন।
